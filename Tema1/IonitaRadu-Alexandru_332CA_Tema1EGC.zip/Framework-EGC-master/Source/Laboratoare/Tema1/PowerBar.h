#pragma once
#include "Transform2D.h"

namespace PowerBar {
	void scaleThePowerBar(glm::mat3& matrixPowerBar, glm::mat3& matrixPowerBarOut, float& angularBow, float& scaleXPowerBar);
}